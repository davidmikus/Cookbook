from functools import wraps
from flask import request, redirect, url_for, session
from app import db_manager




def login_required(f):
    """
    Decorator to ensure that a route can only be accessed by logged-in users.

    Args:
        f (function): The function to be decorated.

    Returns:
        function: The decorated function.

    This decorator checks if a user is logged in by querying the database
    to see if the 'is_logged' field is set to True for the user's email in the session.
    If the user is not logged in, they are redirected to the login page.
    If the user is logged in, the decorated function is called.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        log_check_query = f"""SELECT is_logged From User WHERE email ='{session.get("email")}' """
        is_logged = db_manager.fetchone(log_check_query)
        if not is_logged:
            if 'email' not in session or 'user_id' not in session:
                return redirect('/login')
        return f(*args, **kwargs)
    return decorated_function


