import mysql.connector


class DatabaseManager(object):
    """
    Manages database connections and queries for the Cookbook application.

    Attributes:
        __db_name (str): The name of the database.
        __db_user (str): The database user.
        __db_pass (str): The database user's password.
        __db_host (str): The database host.
        __db_port (int): The database port.
        conn (mysql.connector.connection.MySQLConnection): The database connection.
        cur (mysql.connector.cursor.MySQLCursor): The database cursor.

    Methods:
        check_database(): Checks if the database exists and creates it if not.
        query(arg, values=None): Executes a database query with optional values.
        fetchone(arg, values=None): Executes a database query and returns the first result.
        fetchall(arg, values=None): Executes a database query and returns all results.

    """

    def __init__(self):
        """
        Initializes the DatabaseManager.

        This constructor sets up the database connection and cursor, and checks if the database exists.

        """
        self.__db_name = "cookbook"
        self.__db_user = "root"
        self.__db_pass = "root"
        self.__db_host = "localhost"
        self.__db_port = 3306
        self.conn = mysql.connector.connect(
            user=self.__db_user,
            password=self.__db_pass,
            host=self.__db_host,
            port=self.__db_port,
        )
        self.cur = self.conn.cursor()
        self.check_database()

    def check_database(self):
        try:
            self.cur.execute(f"CREATE DATABASE IF NOT EXISTS {self.__db_name}")

            self.conn.commit()
            self.conn.database = self.__db_name
        except mysql.connector.Error as err:
            print(f"Error: {err}")

    def query(self, arg, values=None):
        try:
            if values is None:
                self.cur.execute(arg)
            else:
                self.cur.execute(arg, values)
            self.conn.commit()
        except Exception as e:
            print(e)

    def fetchone(self, arg, values=None):
        try:
            if values is None:
                self.cur.execute(arg)
            else:
                self.cur.execute(arg, values)
            return self.cur.fetchone()
        except Exception as e:
            print(e)

    def fetchall(self, arg, values=None):
        try:
            if values is None:
                self.cur.execute(arg)
            else:
                self.cur.execute(arg, values)
            return self.cur.fetchall()
        except Exception as e:
            print(e)

    def __del__(self):
        self.conn.close()
