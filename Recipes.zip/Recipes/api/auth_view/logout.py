from flask import redirect, url_for, session
from tools.auth import login_required
from app import app, db_manager


@app.route('/logout')
@login_required
def logout():
    """
    Log out the currently authenticated user.

    Returns:
        Response: A Flask Response object that redirects to the home page.

    This route is protected with the `login_required` decorator to ensure that only
    authenticated users can access it. It updates the user's login status in the
    database to "False," clears the user's session data, and redirects to the home page.
    """
    login_query = f"""UPDATE Users SET is_logged=False Where id={session['user_id']}"""
    db_manager.query(login_query)
    session.pop('email', None)
    session.pop('user_id', None)
    return redirect('/')
