
#auth
from api.auth_view import app
#views
from api.recipes_view import app
