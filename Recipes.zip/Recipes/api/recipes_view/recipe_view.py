from flask import render_template, session, redirect, url_for
from app import app, db_manager
from tools.auth import login_required


@app.route('/recipes/<int:recipe_id>', methods=['GET'])
@login_required
def view_recipe(recipe_id):
    """
    View a recipe by its ID if the user is logged in.

    Args:
        recipe_id (int): The ID of the recipe to be viewed.

    Returns:
        Response: A Flask Response object that renders the view_recipe.html template.

    This route allows logged-in users to view the details of a recipe by its ID.
    It retrieves information about the recipe and the current user, if logged in.
    The data is passed to the template for rendering.
    """
    current_user_id = session['user_id']
    current_user_query = f"""SELECT first_name FROM users WHERE id ={current_user_id};"""
    current_user_name = db_manager.fetchone(current_user_query)[0]
    select_recipes_query = f""" SELECT * FROM recipes WHERE id = {recipe_id};"""
    data = db_manager.fetchone(select_recipes_query)
    recipe_data_dict = {
            "description": data[2],
            "instructions":data[3] ,
            "date_made": data[4],
            "username": current_user_name,
            "under_half_hour":data[5] 

        }

    return render_template('view_recipe.html', recipe=recipe_data_dict, current_user_id=current_user_id, current_user_name=current_user_name)
    