from .recipes import app
from .recipe_view import app
from .recipes_new import app
from .recipe_edit import app
from .delete_recipes import app 
