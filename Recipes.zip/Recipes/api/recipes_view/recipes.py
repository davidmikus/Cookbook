from flask import render_template, session, url_for,request, redirect
from app import app,db_manager
from tools.auth import login_required



@app.route('/recipes', methods = ['GET','POST'])
@login_required
def recipes():
    """
    View a list of recipes and create new recipes if the user is logged in.

    Returns:
        Response: A Flask Response object that renders the recipes.html template.

    This route allows logged-in users to view a list of recipes and create new recipes.
    If the request method is POST, it retrieves the user's recipes and passes them to
    the template for rendering. If the request method is GET, it renders the recipes.html
    template to display the list of recipes.
    """
    current_user_id = session['user_id']
    current_user_query = f"""SELECT first_name AS name FROM users WHERE id="{current_user_id}";"""
    current_user_name = db_manager.fetchone(current_user_query)
    select_recipes_query = f"""SELECT id, name,user_id,under_half_hour FROM recipes;"""
    data = db_manager.fetchall(select_recipes_query)

    print(data)
    recipes_data = []
    if data:
        for i in data:
            select_user_query = f"""SELECT first_name AS name FROM users WHERE id="{i[2]}";"""
            first_name = db_manager.fetchone(select_user_query)
            recipes_data.append({
                'id': i[0], 
                'name': i[1], 
                'user_id': i[2], 
                'under_half_hour': i[3],
                'username':first_name[0]})
    print(recipes_data)
    
    return render_template('recipes.html', recipes=recipes_data, current_user_id=current_user_id, current_user_name=current_user_name[0])

