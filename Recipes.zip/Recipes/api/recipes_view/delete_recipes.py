from app import app,db_manager 
from flask import Flask, redirect, session, flash
from tools.auth import login_required



@app.route('/recipes/delete/<int:recipe_id>', methods=['GET'])
@login_required
def delete_recipe(recipe_id):
    """
    Delete a recipe by its ID if the current user has permission.

    Args:
        recipe_id (int): The ID of the recipe to be deleted.

    Returns:
        Response: A Flask Response object that redirects to the recipes page.

    This route allows logged-in users to delete a recipe. It first checks if the
    current user has permission to delete the recipe by comparing the recipe's
    owner (user_id) with the current user's ID stored in the session. If the user
    has permission, the recipe is deleted from the database. If not, an error flash
    message is displayed, and the user is redirected to the recipes page.
    """
    user_id = session['user_id']
    check_permission_query = f"SELECT user_id FROM recipes WHERE id = {recipe_id}"
    result = db_manager.fetchone(check_permission_query)
    if result[0] == user_id:
        delete_recipe_query = f"DELETE FROM recipes WHERE id = {recipe_id}"
        db_manager.query(delete_recipe_query)
        return redirect('/recipes')
    else:
        flash("You don't have permission to delete this recipe.", 'error')
        return redirect('/recipes')
