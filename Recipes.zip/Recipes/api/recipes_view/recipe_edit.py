from app import app
from flask import render_template, session, redirect, url_for, request, flash
from app import app, db_manager
from tools.auth import login_required


@app.route('/recipes/edit/<int:recipe_id>', methods=['GET', 'POST'])
@login_required
def edit_recipe(recipe_id):
    """
    Edit a recipe by its ID if the current user has permission.

    Args:
        recipe_id (int): The ID of the recipe to be edited.

    Returns:
        Response: A Flask Response object that redirects to the recipes page.

    This route allows logged-in users to edit a recipe. If the request method is GET,
    it retrieves the recipe data and checks if the user has permission to edit it.
    If the user has permission, the recipe data is passed to the template for editing.
    If the request method is POST, it updates the recipe data in the database.

    The function checks if the user has permission to edit the recipe by comparing the
    recipe's owner (user_id) with the current user's ID stored in the session. If the
    user has permission, the recipe is updated in the database, and a success flash
    message is displayed. If not, an error flash message is displayed.
    """
    if request.method =='GET':
        recipe_query = f"""SELECT * FROM recipes WHERE id = {recipe_id};"""
        recipe_data = db_manager.fetchone(recipe_query)

        if not recipe_data:
            flash("Recipe not found", "error")
            return redirect('/recipes')

        recipe = {
            'id': recipe_data[0],
            'name': recipe_data[1],
            'description': recipe_data[2],
            'instruction': recipe_data[3],
            'date_made': recipe_data[4],
            'under_half_hour': bool(recipe_data[5]),
            'user_id': recipe_data[6]
        }

        if recipe['user_id'] != session['user_id']:
            flash("You don't have permission to edit this recipe", "error")
            return redirect('/recipes')
        return render_template('edit_recipe.html', recipe=recipe)

    elif request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        instruction = request.form['instruction']
        date_made = request.form['date_made']
        under_half_hour = bool(request.form.get('under_half_hour'))
        print(1)
        update_recipe_query = f"""
            UPDATE recipes
            SET name = '{name}', description = '{description}', instruction = '{instruction}',
                date_made = '{date_made}', under_half_hour = {under_half_hour}
            WHERE id = {recipe_id};
        """
        db_manager.query(update_recipe_query)
        print(2)

        flash("Recipe updated successfully", "success")
        return redirect('/recipes')

