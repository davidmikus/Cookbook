from flask import render_template, session, url_for,request, redirect,flash
from app import app,db_manager
from tools.auth import login_required



@app.route("/recipes/new",methods = ['GET','POST'])
@login_required
def new_recipes():
    """
    Create a new recipe if the user is logged in.

    Returns:
        Response: A Flask Response object that renders the new_recipes.html template.

    This route allows logged-in users to create a new recipe. If the request method is POST,
    it validates the form data, inserts a new recipe into the database, and redirects to the
    recipes page. If the request method is GET, it renders the new_recipes.html template
    for creating a new recipe.
    """
    if request.method == 'POST':
        name = request.form['name']
        if len(name) <=3:
            flash("name must be more than 2 characters", 'error')
            return render_template("new_recipes.html") 
        description = request.form['description']
        if len(description) <=3:
            flash("des must be more than 3 characters", 'error') 
            return render_template("new_recipes.html")
        instruction = request.form['instructions']
        if len(instruction) <=3:
            flash("instruction must be more than 3 characters", 'error')
            return render_template("new_recipes.html")
        date_made = request.form['date_made']
        under_half_hour = bool(request.form.get('under_half_hour'))
        current_user_id = session['user_id']


        insert_query = f"""
            INSERT recipes (name, description, instruction, date_made, under_half_hour,user_id)
            VALUES ('{name}', '{description}', '{instruction}', '{date_made}', {under_half_hour}, {current_user_id})
        """
        db_manager.query(insert_query) 

        return redirect(url_for('recipes'))
    else:
        return render_template('new_recipes.html')
